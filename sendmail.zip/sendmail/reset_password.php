<?php
session_start();
if (isset($_SESSION['status']) && isset($_SESSION['message'])) {
$status = $_SESSION['status'];
$message = $_SESSION['message'];
echo "<div class='alert {$status}'>{$message}</div>";
unset($_SESSION['status']);
unset($_SESSION['message']);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon" href="./image/logo.png" type="image/x-icon">
<title>Reset your password</title>
<style>
body {
font-family: Arial, sans-serif;
background-color: #f3f4f6;
margin: 0;
padding: 0;
display: flex;
justify-content: center;
align-items: center;
height: 100vh;
}
H2 {
width: 100%;
text-align: center;
}
form {
display: flex;
flex-direction: column;
background-color: white;
padding: .5rem;
border-radius: 10px;
box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
max-width: 400px;
width: 30rem;
}
form input {
padding: .5rem;
margin-bottom: .5rem;
border: 1px solid #ccc;
border-radius: 5px;
font-size: 1rem;
color: #555;
transition: border-color 0.3s ease;
}
form input:focus {
border-color: #4a90e2;
outline: none;
}
form button {
width: 100%;
padding: 12px;
background-color: #4a90e2;
color: white;
border: none;
border-radius: 5px;
font-size: 16px;
cursor: pointer;
transition: background-color 0.3s ease;
}
form button:hover {
background-color: #357abd;
}
form input::placeholder {
color: #aaa;
}
@media (max-width: 600px) {
form {
padding: 20px;
}
}
</style>
</head>
<body>
<form action="includes/login/reset_password.inc.php" method="post">
<h2>CREATE NEW PASSWORD</h2>
<input type="hidden" name="token" value="<?php echo htmlspecialchars($_GET['token']); ?>">
<input type="password" name="pass" placeholder="Enter new password" required>
<input type="password" name="pass_confirm" placeholder="Confirm new password" required>
<button type="submit">Confirm</button>
</form>
</body>
</html>

