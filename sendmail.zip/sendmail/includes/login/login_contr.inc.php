<?php

declare(strict_types=1);

function is_input_empty(string $username, string $pass) 
{
    if(empty($username) || empty($pass))
    {
        return true;
    }
    else 
    {
        return false;
    }
}

function is_user_wrong(array|bool $result) {

    if (!$result) 
    {
        return true;
    }
    else 
    {
        return false;
    }
}

function is_password_wrong(string $password, string $hashedPassword) {
    if (!password_verify($password, $hashedPassword)) 
    {
        return true;
    } 
    else 
    {
        return false;
    }
}