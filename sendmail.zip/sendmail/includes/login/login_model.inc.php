<?php

declare(strict_types=1);

function get_user(object $pdo, string $username) {
    $query = "SELECT * FROM users WHERE gmail = :username;";
    $stmt = $pdo->prepare($query);
    $stmt->bindParam(":username", $username);
    $stmt->execute();
    
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

function store_forgotpassword_data(object $pdo,string $token,string $expiry,string $email) {
    $query = "UPDATE users SET reset_token = :token, token_expiry = :expiry WHERE gmail = :email";
    $stmt = $pdo->prepare($query);
    $stmt->bindParam(':token', $token);
    $stmt->bindParam(':expiry', $expiry);
    $stmt->bindParam(':email', $email);
    $stmt->execute();
}
