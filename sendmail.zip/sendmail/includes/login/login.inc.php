<?php
session_start();
if ($_SERVER["REQUEST_METHOD"] === "POST") {
$username = filter_var($_POST["gmail"], FILTER_SANITIZE_EMAIL);
$pass = $_POST["password"];
if (isset($_POST["g-recaptcha-response"]) && !empty($_POST["g-recaptcha-response"])) {   
$secretKey = '6Lf-J1kqAAAAAL_ywZUCxWBYGJg4h5ck-yOcCxIO'; 
$verifyResponse = file_get_contents('https://www.google.com/recaptcha/api/siteverify?secret=' . $secretKey . '&response=' . $_POST["g-recaptcha-response"]);
$response = json_decode($verifyResponse); 
if ($response->success) {
try {
require_once '../dbh.inc.php';
require_once 'login_model.inc.php';
require_once 'login_contr.inc.php';
$errors = [];
if (is_input_empty($username, $pass)) {
$errors["empty"] = "Please fill in all fields!";
}
$result = get_user($pdo, $username);
if (is_user_wrong($result)) {
$errors["login_incorrect"] = "Incorrect login details!";
}
if (!is_user_wrong($result) && is_password_wrong($pass, $result['pass'])) {
$errors["login_incorrect"] = "Incorrect login details!";
}
require_once '../config_session.php';
if ($errors) {
$_SESSION["error_login"] = $errors;
$_SESSION["signup_data"] = $_POST; 
header("Location: ../../login.php");
die();
}
session_regenerate_id(true);
$newSessionId = session_id() . "_" . $result["id"];
session_id($newSessionId);
$_SESSION["user_id"] = $result["id"];
$_SESSION["user_name"] = htmlspecialchars($result["username"]);
$_SESSION["first_name"] = htmlspecialchars($result["first_name"]);
$_SESSION["last_name"] = htmlspecialchars($result["last_name"]);
$_SESSION["last_regeneration"] = time();
header("Location: ../../home.php?login=success");
$pdo = null;
die();
} catch (PDOException $e) {
die("Query failed: " . $e->getMessage());
}
} else {
$_SESSION["status"] = "Recaptcha verification failed: " . implode(", ", $response->{'error-codes'});
header('Location: ../../login.php');
die();
}
} else {
$_SESSION["status"] = "Recaptcha verification error! Please complete the CAPTCHA.";
header('Location: ../../login.php');
die();
}
} else {
header('Location: ../../login.php');
die();
}