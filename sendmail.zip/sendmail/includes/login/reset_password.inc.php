<?php
session_start();
require_once '../dbh.inc.php';
require_once 'login_model.inc.php';
if ($_SERVER["REQUEST_METHOD"] === "POST") {
$token = $_POST['token'];
$newPassword = $_POST['pass'];
$Password_confirm = $_POST['pass_confirm'];
if ($newPassword !== $Password_confirm) {
$_SESSION['status'] = 'error';
$_SESSION['message'] = 'Passwords do not match!';
header('Location: ../../reset_password.php?token=' . $token);
exit();
}
if (empty($newPassword) || strlen($newPassword) < 8) {
$_SESSION['status'] = 'error';
$_SESSION['message'] = 'Password must be at least 8 characters long.';
header('Location: ../../reset_password.php?token=' . $token);
exit();
}
$query = "SELECT reset_token, token_expiry FROM users WHERE reset_token = :token";
$stmt = $pdo->prepare($query);
$stmt->bindParam(':token', $token);
$stmt->execute();
$user = $stmt->fetch(PDO::FETCH_ASSOC);
if ($user) {
$tokenExpiry = $user['token_expiry'];
$currentTime = date("Y-m-d H:i:s");
if ($currentTime > $tokenExpiry) {
$_SESSION['status'] = 'error';
$_SESSION['message'] = 'Token has expired!';
header('Location: ../../reset_password.php?token=' . $token);
exit();}
$hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
$query = "UPDATE users SET pass = :pass, reset_token = NULL, token_expiry = NULL WHERE reset_token = :token";
$stmt = $pdo->prepare($query);
$stmt->bindParam(':pass', $hashedPassword);
$stmt->bindParam(':token', $token);
$stmt->execute();
$_SESSION['status'] = 'success';
$_SESSION['message'] = 'Password has been updated.';
header('Location: ../../login.php');
$pdo = null;
exit();
} else {
$_SESSION['status'] = 'error';
$_SESSION['message'] = 'Invalid or expired token!';
header('Location: ../../reset_password.php?token=' . $token);
exit();
}
} else {
$_SESSION['status'] = 'error';
$_SESSION['message'] = 'Unauthorized access!';
header('Location: ../../login.php');
exit();}




