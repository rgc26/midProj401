<?php 

declare(strict_types=1);

function welcome(){
    if (isset($_GET['login']) && $_GET['login'] === "success"){
        echo '<script>alert("Welcome, ' . $_SESSION['first_name'] . '")</script>';
    }
}

function fullname()
{
    if (isset($_SESSION["first_name"]) && isset($_SESSION["last_name"])) {
        echo '<h6>' . $_SESSION["last_name"] . ' , '   . $_SESSION["first_name"] . '</h6>';
    }
}


