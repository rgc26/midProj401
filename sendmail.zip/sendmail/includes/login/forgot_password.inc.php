<?php
require_once '../dbh.inc.php';
require_once 'login_model.inc.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require '../../PHPMailer/src/Exception.php';
require '../../PHPMailer/src/PHPMailer.php';
require '../../PHPMailer/src/SMTP.php';
session_start();
if ($_SERVER["REQUEST_METHOD"] === "POST") 
{

    $email = filter_var($_POST['gmail'], FILTER_SANITIZE_EMAIL);
    $user = get_user($pdo, $email);
    if ($user) 
    {
        $token = bin2hex(random_bytes(50));
        $expiry = date("Y-m-d H:i:s", strtotime('+1 hour'));    
        store_forgotpassword_data($pdo, $token, $expiry, $email); 
        $resetLink = "localhost/sendmail/reset_password.php?token=$token";
        $mail = new PHPMailer(true);
        try {
            $mail->isSMTP();                                                
            $mail->Host       = 'smtp.gmail.com';                             
            $mail->SMTPAuth   = true;                                        
            $mail->Username   = 'Php.Mailer.Sample.T.e.S.t@gmail.com';       
            $mail->Password   = 'atvb tapd zmtb coav';                      
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;              
            $mail->Port       = 587;                                         
            $mail->setFrom('Sendmail@gmail.com', 'From Send Mail');  
            $mail->addAddress($email, 'New User');                         
            $mail->isHTML(true);                                    
            $mail->Subject = 'Password Reset Request';
            $mail->Body    = "Hi, please click the following link to reset your password: <a href='$resetLink'>Reset Password</a>";
            $mail->send(); 
            $_SESSION['status'] = 'success';
            $_SESSION['message'] = 'Password reset email has been sent!';
        } catch (Exception $e) {
            $_SESSION['status'] = 'error';
            $_SESSION['message'] = "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
        }
        header('Location: ../../forgot_password.php');
        exit();
    } 
    else{$_SESSION['status'] = 'error';$_SESSION['message'] = 'Email not found.';header('Location: ../../forgot_password.php');exit();}
}