<?php
declare(strict_types=1);
function signup_name_data() {
if(isset($_SESSION["signup_data"]["firstname"]))
{
echo '<input type="text" name="first_name" class="form-control input" 
value="' . $_SESSION["signup_data"]["firstname"] . '">';
} else {
echo '<input type="text" name="first_name" class="form-control input">';
}
}
function signup_lastname_data() {
if(isset($_SESSION["signup_data"]["lastname"]))
{
echo '<input type="text" name="last_name"  class="form-control input"
value="' . $_SESSION["signup_data"]["lastname"] . '">';
} else {
echo '<input type="text" name="last_name" class="form-control input">';
}
}
function signup_gmail_data() {
if (isset($_SESSION["signup_data"]["gmail"]) 
&& !isset($_SESSION["error_signup"]["gmail_taken"]) 
&& !isset($_SESSION["error_signup"]["invalid_gmail"]))
{
echo '<input type="text" name="gmail" class="form-control input"
value="' . $_SESSION["signup_data"]["gmail"] . '">';
} else {
echo '<input type="text" name="gmail" class="form-control input">';
} 
}
function display_invalid_gmail_error() {
if (isset($_SESSION["error_signup"]))
{
$errors = $_SESSION["error_signup"];

foreach($errors as $error) {
echo '<p class="error">' . $error . '<p &nbsp;>';
}
unset($_SESSION["error_signup"]);
} elseif (isset($_GET["msg"]) && $_GET["msg"] === "success") {
echo "<br>";
echo '<p class="success">Signup Success!</p>';
}
} 
function recaptcha_verification() {
if(isset($_SESSION["Status"])){
echo '<p>' . $_SESSION["Status"] . '</p>';
unset($_SESSION["status"]);
}
}

