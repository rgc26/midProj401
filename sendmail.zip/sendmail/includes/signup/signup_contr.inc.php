<?php

declare(strict_types=1);

function is_input_empty(string $first_name, string $last_name, string $gmail, string $password, string $confirm_password) 
{
if (empty($first_name) || empty($last_name) || empty($gmail) || empty($password) || empty($confirm_password)){
return true;
} else {
return false;
}
}
function is_password_short(string $password){
if($password > 8){
return true;
}else{
return false;
}
}
function is_gmail_invalid(string $gmail)
{
if(!filter_var($gmail, FILTER_VALIDATE_EMAIL)){
return true;
} else {
return false;
}
}

function is_password_match(string $password, string $confirm_password) 
{
if($password != $confirm_password){
return true;
} else {
return false;
}    
}

function is_gmail_taken(object $pdo, string $gmail)
{
if (is_gmail_already_signedup ($pdo, $gmail)) {
return true;
} else {
return false;
}
}

function create_user(object $pdo, string $first_name, string $last_name, string $gmail, string $password)
{
set_user($pdo, $first_name, $last_name, $gmail, $password);
}