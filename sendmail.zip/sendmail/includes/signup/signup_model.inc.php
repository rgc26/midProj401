<?php
declare(strict_types=1);
function is_gmail_already_signedup (object $pdo, string $gmail)
{
$query = "SELECT gmail FROM users WHERE gmail = :gmail;";
$stmt = $pdo->prepare($query);
$stmt->bindParam(":gmail", $gmail);
$stmt->execute();
$result = $stmt->fetch(PDO::FETCH_ASSOC);
return $result;
}
function set_user(object $pdo, string $first_name, string $last_name, string $gmail, string $password)
{
$query = "INSERT INTO users ( first_name ,  last_name ,  gmail ,  pass ) 
VALUES  (:first_name , :last_name , :gmail , :pass);";
$stmt = $pdo->prepare($query);
$option = [
'cost' => 12
];
$pwhash = password_hash($password, PASSWORD_BCRYPT, $option);
$stmt->bindParam(":first_name", $first_name);
$stmt->bindParam(":last_name", $last_name);
$stmt->bindParam(":gmail", $gmail);
$stmt->bindParam(":pass", $pwhash);
$stmt->execute();
}