<?php
if ($_SERVER["REQUEST_METHOD"] === "POST") {
$first_name = $_POST["first_name"];
$last_name = $_POST["last_name"];
$gmail = $_POST["gmail"];
$password = $_POST["password"];
$confirm_password = $_POST["confirm_password"];
if(isset($_POST["g-recaptcha-response"]) && !empty($_POST["g-recaptcha-response"]))
{
$secretKey = '6Lf-J1kqAAAAAL_ywZUCxWBYGJg4h5ck-yOcCxIO';
$verifyResponse = file_get_contents('https://www.google.com/recaptcha/api/siteverify?secret=' . $secretKey . '&response=' . $_POST["g-recaptcha-response"]);
$response = json_decode($verifyResponse);
if($response->success)
{
try{
require_once '../dbh.inc.php';
require_once 'signup_model.inc.php';
require_once 'signup_contr.inc.php';
$errors = [];
if(is_input_empty ($first_name, $last_name ,$gmail ,$password ,$confirm_password)) {
$errors["empty"] = "Please fill in all the fields!";
}
if (is_gmail_invalid ($gmail)) {
$errors["invalid_gmail"] = "Invalid gmail!";
}
if (is_password_short($password)){
    $errors["short_pass"] = "Password is too short!";
}
if (is_password_match ($password, $confirm_password)) {
$errors["not_match"] = "Password do not match!";
}
if (is_gmail_taken ($pdo, $gmail)) {
$errors["gmail_taken"] = "Gmail is already used!";
}
require_once '../config_session.php';
if ($errors){
$_SESSION["error_signup"] = $errors;
$signup_user_data = [
"firstname" => $first_name,
"lastname" => $last_name,
"gmail" => $gmail,
];
$_SESSION["signup_data"] = $signup_user_data;
header("Location: ../../sign_up.php");
die();
}
create_user($pdo, $first_name, $last_name, $gmail, $password);
header('Location: ../../sign_up.php?msg=success');
$pdo = null;
$stmt = null;
die();
}
catch(PDOException $e)
{
die("Query failed: " . $e->getMessage());
}
}
else
{
$_SESSION["status"] = "Recaptcha verification failed: " . implode(", ", $response->{'error-codes'});
header('Location: ../sign_up.php');
die();
}
}
else
{   
$_SESSION["status"] = "Recaptcha verification error! Please complete the CAPTCHA.";
header('Location: ../sign_up.php');
die();
}
} else {
header('Location: ../sign_up.php');
die();
}