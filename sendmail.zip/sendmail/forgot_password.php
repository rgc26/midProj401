<?php
include_once "./includes/config_session.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon" href="./image/logo.png" type="image/x-icon">
<title>Forgot Password</title>
<style>
body{
width: 100%;
height: 100vh;
display: flex;
justify-content: center;
align-items: center;
}

form{
padding: .5rem;
width: 30rem;
display: flex;
flex-direction: column;
justify-content: center;

background: rgba( 0, 0, 0, 0.25 );
box-shadow: 0 8px 32px 0 rgba( 31, 38, 135, 0.37 );
backdrop-filter: blur( 4px );
-webkit-backdrop-filter: blur( 4px );
border-radius: 10px;
border: 1px solid rgba( 255, 255, 255, 0.18 );
}

form label {
display: block;
margin-bottom: 10px;
font-size: 16px;
font-weight: bold;
color: #333;
}

/* Input styling */
form input {
padding: .5rem;
margin: 0 0 .5rem 0;
border: 1px solid #ccc;
border-radius: 5px;
font-size: 1rem;
color: #555;
transition: border-color 0.3s ease;
}

form input:focus {
border-color: #4a90e2;
outline: none;
}

/* Button styling */
form button {
text-align: center;
width: 100%;
padding: 12px;
background-color: #4a90e2;
color: white;
border: none;
border-radius: 5px;
font-size: 16px;
cursor: pointer;
transition: background-color 0.3s ease;
}

form button:hover {
background-color: #357abd;
}

/* Additional styling */
form input::placeholder {
color: #aaa;
}
</style>


<script>
function showAlert(message, status) {
if (status === 'success') {
alert("Success: " + message);
} else if (status === 'error') {
alert("Error: " + message);
}
}
</script>
</head>
<body>

<?php
// Check if there's a message in the session
if (isset($_SESSION['status']) && isset($_SESSION['message'])) {
$status = $_SESSION['status'];
$message = $_SESSION['message'];

// Display alert using JavaScript
echo "<script>showAlert('$message', '$status');</script>";

// Unset session variables after displaying
unset($_SESSION['status']);
unset($_SESSION['message']);
}
?>

<!-- Rest of the forgot password page -->
<form action="./includes/login/forgot_password.inc.php" method="post">
<label for="email">Enter your Gmail:</label>
<input type="email" name="gmail" required>
<button type="submit">Submit</button>
</form>
</body>
</html>
